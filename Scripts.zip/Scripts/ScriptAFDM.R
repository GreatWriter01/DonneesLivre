#Charger le fichier DataAFDM.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataAFDM.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataAFDM,package="DataBoo")

# 1 Lecture des donnees (2 var. quanti. et 3 var qualit.----
Donnees = DataAFDM
MyB2= Donnees ; head(MyB2) ; noms=names(MyB2)
Nlig = nrow(MyB2); Nlig ; nbcol2 = ncol(MyB2); nbcol2
# 2 Création des deux sous matrices (qualit. et quanti)----
nature = c(0, nbcol2) ;
for (i in 1:nbcol2){ nature[i]=typeof(MyB2[[i]])}
quali =which(nature == "character" |nature =="logical")
quanti = which(nature == "double")
Nbquali =length(quali); Nbquali ; Xquali=MyB2[quali]
Nbquanti =length(quanti); Nbquanti
Xquanti= MyB2[quanti]
# 3 Centrage et reduction des donnees quanti----
Xquanti_R = scale(Xquanti)
round(head(Xquanti_R,),digits =2)
round(apply(Xquanti_R,2,mean))   # =>moyennes =0
round(apply(Xquanti_R,2,sd))   # => écarts-type =1
# 4 Codage des variables qualitatives----
for (i in 1: Nbquali) {
  Xquali[which(Xquali [,i]=="A"),i]="1"
  Xquali [which(Xquali [,i]=="B"),i]="2"
  Xquali [which(Xquali [,i]=="C"),i]="3"
} ; tp = as.numeric(as.matrix(Xquali)) ; A= Nbquanti+1
tp = matrix(tp, Nlig) ; Xquali = as.data.frame(tp, NULL) ; colnames(Xquali)= noms[A: nbcol2] ; head(Xquali)
#  5 Creation du TDC avec variables codees----
M = 0              # Calcul du nb de modalités de chq variable
for(i in 1:Nbquali){
  M[i]=max(Xquali[,i])-min(Xquali[,i])+1 ;  print(M[i])
} ; Som_mi =sum(M); Som_mi   # nb de colonnes du TDC
TDC =matrix(0,nrow=Nlig,ncol=Som_mi)  ;  Index =0
for(j in 1:Nbquali){
  for(i in 1:Nlig){TDC[i,Index+as.integer(Xquali[i,j])]=1}
  Index = Index+M[j] ;   print(Index)
}  ; head(TDC)
apply(TDC,1,sum)      # somme de chq ligne = nb de var.
Tot_col = apply(TDC,2,sum);Tot_col  # Somme des colonnes
sum(apply(TDC,2,sum))  # Som. des som = nb de vbles*N
# 6 Construction du tableau des fréquences----
Freq_Qual = matrix(0,nrow=Nlig,ncol=Som_mi)
for (j in 1:Som_mi){
  for(i in 1:Nlig){Freq_Qual[i,j]= TDC[i,j]/sqrt(Tot_col[j]/Nlig)}
}
Freq_Qual[which(Freq_Qual=="NaN")]=0
round(apply(Freq_Qual,2,sum), digits = 2)
round(head(Freq_Qual),digits = 2)
# 7 AFDM : 3 méthodes :
#                           AFDM A la « main »----
XMat = cbind2(Xquanti_R,Freq_Qual) ;  dim(XMat)
Mat_Cov= (1/Nlig)*t(XMat) %*% XMat ; dim(Mat_Cov)
Res1 = eigen(Mat_Cov); round(Res1$values,2) # Val propres
#  ACP non normée sur X centrée réduite & fréquences----
Res2=PCA(XMat, scale.unit = FALSE, graph = TRUE); Res2$eig # ACP récupération des valeurs propres
#      AFDM sur données Brutes (FactoMineR)----
for (i in 5:7) { # distinction des modalités pour graphiques
  temp = as.character(i)
  Donnees[which(Donnees[,i]=="A"),i]= paste("A-",temp)
  Donnees[which(Donnees[,i]=="B"),i]= paste("B-", temp)
  Donnees[which(Donnees[,i]=="C"),i]= paste("C-", temp)
} ; Donnees
XMat2 =cbind2(Xquanti, Donnees [A:nbcol2]) ; head(XMat2)
# AFDM et récupération des valeurs propres
Res3=FAMD(XMat2, graph = TRUE); Res3$eig
