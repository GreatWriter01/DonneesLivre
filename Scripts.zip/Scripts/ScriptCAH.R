## 1- Chargement des packages----
library(rgl)     # ne fonctionne pas sur MAC
library(stats) ; library(ggplot2) 
## 2-Matrice de données----
x1=c(7,3,6,1,6) 
x2=c(1.5,3,2,3,6)
x3=c(2,4,6,5,1)
X = data.frame(x1,x2,x3)
## 3-Graphique du nuage avec plot3d de rgl----
plot3d(x1,x2,x3, type="s", radius = 0.5, col = "black") # package rgl (pas sur MAC)
## 4-Distances euclidiennes entre individus----
d = dist(X)
print(d)
cah=hclust(d,method="ward.D2") #pkg stats
# 5-CAH----
plot(cah, hang=-1) #feuilles au même niveau
## 6-Hauteurs d'agrég. du dendrogramme----
H=rev(cah$height ); round(H, digits = 3)
# 7 Variation d’Inertie W en fonction du noeud----
Delta.W=(H^2)/(2*5)
Inertie.tot = sum(Delta.W) ; Inertie.tot
R.part=c(Delta.W,0)/ Inertie.tot
round(R.part, digits =2)
## 8-Graphique de l’inertie----
plot(c(Delta.W,0),type="l",xlab = "Nombre de groupes",ylab = "variation de l’Inertie Intra", main="Variation I-intra sur I-total en fonction du nombre de groupes",xlim=c(1,5))
