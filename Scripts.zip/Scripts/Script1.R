#EXEMPLE DE PROGRAMME
#Programme pour créer une matrice
## Création d'un vecteur----
X=c(2,4,23,5,3,6,8,7,9,23)
X
## Création d'une matrice----
Y=matrix(X,nrow=5,ncol=2,byrow=FALSE)
## Explication sur la formule de la matrice----
# ncol donne le nombre de colonnes de la matrice
# nrow donne le nombre de ligne de la matricey=x
## Extraire des éléments de la matrice----
Y[2,2] # affiche la valeur se trouvant sur ligne 2 et colonne 2
Y[4, ] # affiche la ligne 4
Y[1:3, ] # affiche les lignes 1 à 3 de Y
Y[,2] # affiche la colonne 2