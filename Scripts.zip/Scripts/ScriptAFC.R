#Charger le fichier DataAFC.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataAFC.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataAFC,package="DataBoo")
## 1  Lecture et codage des données----
Z=DataAFC
str(Z)       ;      Nlig = nrow(Z)      ;      Ncol = ncol(Z)
## 2 Tableau de contingence et sous matrices X1 et X2----
M = 0
for(i in 1:5){  M[i]=max(Z[,i])-min(Z[,i])+1 }
Som_mi =sum(M)
NCOL_TDC =M[1]+M[4]
TDC =matrix(0,nrow=Nlig,ncol=NCOL_TDC) ; Index =0
for(i in 1:Nlig){TDC[i,Index+as.integer(Z[i,1])]=1}
for(j in 1:3){Index = Index+M[j]}
for(i in 1:Nlig){  TDC[i,M[1]+as.integer(Z[i,4])]=1  }
X1 =matrix(0,nrow=Nlig,ncol=M[1])
X1 = TDC[,1:M[1]]     ;     head(X1,2)    ;   Debut = M[1]+1
X2 = TDC[,Debut:NCOL_TDC]            ;    head(X2,2)
TC = t(X1) %*% X2     ;    TC
## 3 test du chi2----
chisq.test(TC)
## 4 Matrices des profils-lignes L et colonne C----
n=sum(TC)                 ;   gc=apply(TC,2,sum)/n; gr=apply(TC,1,sum)/n
# Métriques
Dr=diag(gr)               ;    Dc=diag(gc)
Dr1=diag(1/gr)         ;    Dc1=diag(1/gc)
# Profils-lignes et colonnes
L=t(TC)%*%Dr1/n    ;    C= TC%*%Dc1/n
# 5 Diagonalisation LC et CL => Valeurs propres----
rLC = eigen(L%*%C)  ;    round(rLC$values, digits = 3)
rCL = eigen(C%*%L)  ;    round(rCL$values, digits = 3)
# 6 Décomposition spectrale => valeurs singulières----
res=svd(sqrt(Dr1)%*%TC%*%sqrt(Dc1)/n)
round(res$d^2 , 3) # valeurs singulières au carré
## 7 Orthogonalité des vecteurs propres----
L=res$d[-1] # valeur singulière 1 à retirer
# Rechangement de métrique
U=diag(sqrt(gr))%*%res$u[,-1]
V=diag(sqrt(gc))%*%res$v[,-1]
round(t(U)%*%Dr1%*%U,digits =2)
round(t(V)%*%Dc1%*%V,digits =2)
## 8 AFC avec FatoMineR----
library(FactoMineR) ; res.afc=CA(TC)
res.afc$eig

