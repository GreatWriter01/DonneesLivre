#Charger le fichier DataACP.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataACP.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataACP,package="DataBoo")
#retire les 2 premières colonnes
X=as.matrix(DataACP[,c(-1,-2)])
N=nrow(X)-1
#itération pour déterminer K
nbr=c()
for(k in 1:N){
  tmp=kmeans(X,centers=k)
  nbr[k]=tmp$withinss/tmp$totss
}
plot(1:N,nbr,xlim=c(1,N),ylab="R carré semi-partiel",xlab="nombre de groupes",type="p", main="R carré semi-partiel vs nb de groupes")


