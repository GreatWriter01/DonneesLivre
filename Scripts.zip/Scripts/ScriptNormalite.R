X =c(6, 5, 7, 6, 6, 6, 6, 6, 6, 7, 6, 6, 7, 6, 6, 7, 7, 6, 7, 6)
#Tracé de la courbe
hist(X, prob=T)
curve(dnorm(x,mean(X),sd(X)),add=T,col="red")
#Test de shapiro
shapiro.test(X)
#Test de Lilliefors
library(nortest)
lillie.test(X) #package nortest

