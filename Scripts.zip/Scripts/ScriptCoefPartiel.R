## Création de la fonction----
coef.corre.partiel = function(A,B,C) { 
  #coef de corrélation partiel entre A et B, en contrôlant les effets de C  
  # méthodes de Pearson
  #            ne pas oublier les guillemets 
  a=cor(cbind(A,B),method="pearson")[1,2]
  b=cor(cbind(B,C),method="pearson")[1,2]
  c=cor(cbind(A,C),method="pearson")[1,2]
  cat(round(a,digits=2), round(b,digits=2), round(c,digits=2))
  #                                     Formule du coefficient de corrélation partiel
  x=(a-(b*c))/(sqrt(1-c^2)*sqrt(1-b^2)) ;   round(x, digits=2)   # résultat 
}	
## utilisation de la fonction----
A=1:10   ; A= log(A)			
B=11:20 ; B= exp(B)
C=21:30
coef.corre.partiel(A,B,C)	

