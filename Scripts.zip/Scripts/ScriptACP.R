#Charger le fichier DataACP.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataACP.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataACP,package="DataBoo")
## 1 Normalisation de la matrice Z----
Z=as.matrix(DataACP[,c(-1,-2)]);str(Z)
X =scale(Z) ; X
# Dimensions de la matrice X
N =nrow(Z) ; N ; k =ncol(Z) ; k  # Nb Obs & Variab
## 2 Matrice de correlation (3 methodes)----
COR_1 = (t(X) %*% X)/(N-1)
head(COR_1[,1:3],2)
COR_2 = cov(X) ; head(COR_2[,1:3],2)
COR_3 =cor(Z) ; head(COR_3[,1:3],2)
## 3 Tableau des valeurs propres----
Diag = eigen(COR_2)    # Diagonalisaton
Lbd = Diag$values      # Valeurs propres
Pt_Inertie = Lbd /sum(Lbd) #% inertie expliquee
# Somme cumulee des % inertie
Pt_Inertie_cum = cumsum(Pt_Inertie)
Tmp =cbind(Lbd, Pt_Inertie, Pt_Inertie_cum)
library(knitr)
kable(round(Tmp,2), caption ="Inertie, % et cumul", format ="pipe")
## Graphique des ?boulis----
plot(Tmp[,1], main="Scree plot",ylab = "Valeurs propres", type ="l")
## 4 Scores et saturations----
VectPr = as.matrix(Diag$vectors)
NLbd=max(which(Lbd>=1)) # crit. de Catell
# Scores
F = X %*% VectPr
# Saturations
Phi= COR_2 %*% VectPr /(sqrt(Lbd)*(N-1))
## Qualit?s et contributions des variables----
Qual_Var =matrix(0,nrow=k,ncol= NLbd)
Ctr_Var = matrix(0,nrow=k,ncol= NLbd)
for(j in 1:k){
  Som_Qual = sum(Phi[j,]^2)
      for(h in 1: NLbd){
          Qual_Var[j,h] =Phi[j,h]^2/ Som_Qual
          Ctr_Var[j,h] = Phi[j,h]^2/ sum(Phi[,h]^2)
      }
  }
round(apply(Qual_Var,1,sum),2)
apply(Ctr_Var,2,sum)
## Qualit?s et contributions des individus
Qual_Ind = matrix(0,nrow=N,ncol= NLbd)
Ctr_Ind = matrix(0,nrow=N,ncol= NLbd)
for (i in 1:N){
  Som_Qual = sum(F[i,]^2)
  for(h in 1: NLbd){
    Qual_Ind[i,h] =F[i,h]^2/ Som_Qual
    Ctr_Ind[i,h] = F[i,h]^2/ sum(F[,h]^2)
  }}
round(apply(Qual_Ind,1,sum),2)
apply(Ctr_Ind,2,sum)
## 5 Graphiques sur les deux 1ers axes----
plot(F[,1], F[,2],pch = 16,main="Graphique des individus : axes 1 et 2")    # des individus
abline(v=mean(F[,1]))
abline(h=mean(F[,2]))
plot(Phi[,1], Phi[,2],pch = 16, main="Graphique des variables : axes 1 et 2")  # des variables
abline(v=mean(Phi[,1]))
abline(h=mean(Phi[,2]))

