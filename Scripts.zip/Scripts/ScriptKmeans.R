##Chargement des packages----
library(stats) ; library(scatterplot3d) ; library(rgl)
##Matrice des données----
cat("Partitionnement méthode des K-means")
x1=c(7,3,6,1,6); x2=c(1.5,3,2,3,6);x3=c(2,4,6,5,1)
##Méthode K-Means----
K=3    #nombre de clusters choisi
X=data.frame(x1, x2, x3) 
km=kmeans(X, center=K)
print(km)
print(table(km$cluster))   #  nb d'indiv. par cluster
## graphique 3d interactif avec le package rgl----
#
#                             que sur PC
#
plot3d(x1,x2,x3,radius=2,col=c("grey48","grey80","black")[km$cluster], size =20) 
#
# cluster 1 en gris foncé
# cluster 2 en gris clair
# cluster 3 en noir
## graphique 3d avec le package scatterplot3d----
#
#                         sur Mac et PC
#
scatterplot3d(x1,x2,x3,color = c("grey48" , "grey80" , "black")[km$cluster]) 
#
# cluster 1 en cercle
# cluster 2 en étoile
# cluster 3 en triangle
