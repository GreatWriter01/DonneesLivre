# TEST
# Charger le fichier DataResidus.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataResidus.rda
# Test du KHI 2 enregistré dans KHI2
KHI2 = chisq.test(DataResidus[,-1])
KHI2
# Résidus de Pearson
round(KHI2$residuals,1)
# Résidus d’Haberman
round(KHI2$stdres,1)


