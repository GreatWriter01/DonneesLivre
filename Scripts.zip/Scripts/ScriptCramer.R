# V Cramer
# Charger le fichier DataResidus.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataResidus.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataResidus,package="DataBoo")
# Test du KHI 2 enregistré dans KHI2
KHI2 = chisq.test(DataResidus[,-1])
KHI2
#Commandes N° : Création d’une fonction R pour calculer le V de Cramer :
N=sum(DataResidus[,-1])    # Taille d’échantillon en retirant la colonne prof
# Calcul de  m1 et de  m2
m1=nrow(DataResidus);m1
m2=ncol(DataResidus[,-1]);m2
N
# Dénominateur du V de Cramér
Denom=min(m1,m2)-1
# Calcul du V de Cramér
V=sqrt(KHI2$statistic/(N * Denom))
cat("Le V de Cramèr est : ",V)

