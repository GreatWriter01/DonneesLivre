#Charger le fichier DataACP.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataACP.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataACP,package="DataBoo")
##Chargement du package----
library(psych) 
#                  méthode 1----
Z=as.matrix(DataACP[,c(-1,-2)]);str(Z)
ncomp =2
pca_rotated = principal(Z, rotate="varimax", nfactors=ncomp, scores=TRUE)
pca_rotated$loadings  # Saturations 
pca_rotated$rot.mat #matrice de rotation

#                  méthode 2----
pcaZ = PCA(Z, scale.unit = TRUE) #
round(pcaZ$var$coord[,1:2],3) # Saturations, 2 axes
# Rotation varimax des saturations
rotatedLoad= varimax(pcaZ$var$coord[,1:2])$loadings
rotatedLoad
## Verification----
pcaZ$var$coord[,1:2] %*% pca_rotated$rot.mat

