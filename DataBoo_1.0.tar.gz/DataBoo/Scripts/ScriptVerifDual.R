## Création de la matrice X de dimension (5,3)----
Z=matrix(c(10,2,7,8,1,5,4,5,7,6,4,5,3,6,9), byrow= TRUE, ncol=3)
X=scale(Z)      # centrer et réduire Z
round(X,2)    # Affichage de la matrice X
##Matrice de corrélation----
R=cor(X) # Matrice de corrélation
# Affichage, deux décimales
round(R, digits =2) # arrondi à 2 décimales    
N = nrow(X)
S =(X%*%t(X))/(N-1) # (XX’)/(N-1)
# Affichage, deux décimales
N = nrow(X)
S =(X%*%t(X))/(N-1) # (XX’)/(N-1)
# Affichage, deux décimales
round(S, digits=2)
## trace de R et de S----
TraceR= sum(diag(R)) ; TraceS= sum(diag(S)) 
TraceR; TraceS # résultats
## Diagonalisation de R=(X’X)/(N-1)----
vp1 =eigen(R)    
round(vp1$values,digits=2)  # Valeurs propres
round(vp1$vectors,digits=2) # Vecteurs propres
## Diagonalisation de S=(XX’)/(N-1)----
vp2=eigen(S)     
round(vp2$values, digits=2) # Valeurs propres
round(vp2$vectors,digits=2) # Vecteurs propres
##Vérifications----
# Somme des valeurs propres de R=(X’X)/4
round(sum(vp1$values),digits =2)  
# Somme des valeurs propres de S=(XX’)/4
round(sum(vp2$values),digits =2)   
# vérif Orthogonalité vecteurs propres de R
round(t(vp1$vectors) %*%vp1$vectors, digits=2)
# vérif Orthogonalité vecteurs propres de S 
round(vp2$vectors %*% t(vp2$vectors), digits=2)
## Déterminant=produit des # valeurs propres----
det(R)
vp1$values[1]*vp1$values[2]*vp1$values[3]

