## Création de la matrice X de dimension (5,3)----
Z=matrix(c(10,2,7,8,1,5,4,5,7,6,4,5,3,6,9), byrow= TRUE, ncol=3)
round(Z,2)    # Affichage de la matrice Z
##Matrice de correlation----
R=cor(Z) # Matrice de correlation
# Affichage, deux decimales
round(R, digits =2) # arrondi à 2 decimales
## Matrice des anti-images----
invR <- solve(R)     # Invers. de la mat de correl.
A <- matrix(1,nrow(invR),ncol(invR)) #Mat. des corr. partielles
for (i in 1:nrow(invR)){
  if(i <nrow(invR)){
    for (j in (i+1):ncol(invR)){
      #above the diagonal
      A[i,j] <- -invR[i,j]/sqrt(invR[i,i]*invR[j,j])
      #below the diagonal
      A[j,i] <- A[i,j]
    }
  }
}
Zdata=c("Var1","Var2","Var3")
colnames(A) = Zdata  #noms des col.
print(A)

## Calcul du KMO----
# Numerateur du KMO
kmo.num =sum(R^2) - sum(diag(R^2))
# Denominateur du KMO
kmo.denom = kmo.num + (sum(A^2) - sum(diag(A^2)))
kmo = kmo.num/kmo.denom  # indice KMO
cat("Indice KMO :", kmo)
