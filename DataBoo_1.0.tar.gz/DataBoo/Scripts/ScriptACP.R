#Charger le fichier DataACP.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataACP.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataACP,package="DataBoo")
## 1 Normalisation de la matrice Z----
Z=as.matrix(DataACP[,c(-1,-2)]);str(Z)
X =scale(Z) 
# Dimensions de la matrice X
N =nrow(Z) ; k =ncol(Z) # Nb Obs & Var.

cat("N= ",N , "    k= ",k)  
## 2 Matrice de correlation (3 methodes)----
COR_1 = (t(X) %*% X)/(N-1)
head(COR_1[,1:3],1)
COR_2= cov(X) ; head(COR_2[,1:3],1)
COR_3 =cor(Z) ; head(COR_3[,1:3],1)
## 3 Tableau des valeurs propres----
Diag = eigen(COR_2)    # Diagonalisation
Lbd = Diag$values      # Valeurs propres
Pt_Inertie = Lbd /sum(Lbd) #% inertie expliq.
# Somme cumulee des % inertie
Pt_Inertie_cum = cumsum(Pt_Inertie)
Tmp =cbind(1:14,Lbd, Pt_Inertie, Pt_Inertie_cum)
library(knitr)
kable(round(Tmp,2), caption ="Inertie, % et cumul", format ="pipe")
## 4 Graphique des éboulis----
plot(Tmp[,2], main="Scree plot",ylab = "Valeurs propres", type ="l")







## 5 Scores et saturations----
VectPr = as.matrix(Diag$vectors)
NLbd=max(which(Lbd>=1)) # crit. Catell
F = X %*% VectPr   # Scores
# Saturations
Phi=matrix(0,k,2)
Phi[,1]= (COR_2 %*% VectPr[,1])/sqrt(Lbd[1])
Phi[,2]= (COR_2 %*% VectPr[,2])/sqrt(Lbd[2])
## 6 Qualit?s et contributions des var.----
Qual_Var =matrix(0,nrow=k,ncol= NLbd)
Ctr_Var = matrix(0,nrow=k,ncol= NLbd)
for (j in 1:k){
  Som_Qual = sum(Phi[j,]^2)
  for(h in 1: NLbd){
    Qual_Var[j,h] =Phi[j,h]^2/ Som_Qual 
    Ctr_Var[j,h] = Phi[j,h]^2/ sum(Phi[,h]^2)
  }}
round(apply(Qual_Var,1,sum),2)
apply(Ctr_Var,2,sum)
Mtemp =cbind(Phi[,1:2],Ctr_Var,Qual_Var)
colnames(Mtemp) =c("Coord1", "Coord2", "Ctr1", "Ctr2", "Qual1", "Qual2")
kable(round(Mtemp,2), caption = "Tableau des variables")
## 7 Qualit?s & contribu. des individus----
Qual_Ind = matrix(0,nrow=N,ncol= NLbd)
Ctr_Ind = matrix(0,nrow=N,ncol= NLbd)
for (i in 1:N){
  Som_Qual = sum(F[i,]^2)
  for(h in 1: NLbd){
    Qual_Ind[i,h] =F[i,h]^2/ Som_Qual
    Ctr_Ind[i,h] = F[i,h]^2/ sum(F[,h]^2)
  }}
round(apply(Qual_Ind,1,sum),2)
apply(Ctr_Ind,2,sum)
## 8 Graphiques sur les deux 1ers axes----
plot(F[,1], F[,2] ,pch = 16, main="Graphique des individus : axes 1 et 2")    # des individus
abline(v=mean(F[,1]))
abline(h=mean(F[,2]))
plot(Phi[,1], Phi[,2] ,pch = 16, main= "Graphique des variables : axes 1 et 2")  # des variables
abline(v=mean(Phi[,1]))
abline(h=mean(Phi[,2]))
