## I Formation des groupes de pays selon le Pib----
Pib = c(60359, 46935, 67028, 83019, 19402, 9773, 2080, 11468, 17282, 10277); Pib
pays=c("1-Italie","2-Espagne","3-France","4-Allemagne","5-Roumanie","6-Hongrie","7-Slovénie","8-Belgique","9-Pays-Bas","10-Portugal")
Y_Lim = summary(Pib) ;  Y_Lim
Grp1 = which(Pib<Y_Lim[2]) 
Grp2 = which(Pib>Y_Lim[2] & Pib<Y_Lim[3]) 
Grp3 = which(Pib>Y_Lim[3] & Pib<Y_Lim[5])
Grp4 = which(Pib>Y_Lim[5]) 
Groupe = Pib
Groupe[Grp1] =1       # Groupe 1 codé à 1
Groupe[Grp2] =2       # Groupe 2 codé à 2
Groupe[Grp3] =3       # Groupe 3 codé à 3
Groupe[Grp4] =4       # Groupe 4 codé à 4
## II Edition des résultats de la Matrice des résultats----
library(knitr)
#           Création d’un vecteur de commentaires
Valeurs= Groupe
Valeurs[Grp1] = paste("<", as.character(Y_Lim[2]))
Valeurs[Grp2] = paste(as.character(Y_Lim[2]), "<PIB<", as.character(Y_Lim[3]))
Valeurs[Grp3] = paste(as.character(Y_Lim[3])," <PIB<", as.character(Y_Lim[5]))
Valeurs[Grp4] = paste("PIB>", as.character(Y_Lim[5]))
Matrice = cbind(pays,Pib,Groupe,Valeurs); Matrice
##                      Affichage du tableau
kable(Matrice, format ="simple")
