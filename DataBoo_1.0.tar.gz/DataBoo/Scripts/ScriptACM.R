#Charger le fichier DataAFC.xlsx avec Import Dataset dans l’environnement ou double cliquer sur le fichier DataAFC.rda
#Ou alors si le package DataBoo est chargé vous pouvez utiliser la ligne de commande : data(DataAFC,package="DataBoo")
Don = DataAFC 
head(Don,3); str(Don)          # Aperçu des données 
Nlig = nrow(Don) ;  Ncol = ncol(Don) 
# 2 Transformation: AGES -> tranche d'ages---- 
Grp1 = which(Don[,Ncol]<30)                                            
Grp2 = which(Don[,Ncol]>=30 & Don[,Ncol]<45)  
Grp3 = which(Don[,Ncol]>= 45 & Don[,Ncol]<60) 
Grp4 = which(Don[,Ncol]>=60)                                          
#        Affecter le code chaque groupe 
Don[Grp1,Ncol] =1  ; Don[Grp2,Ncol] =2 ;   Don[Grp3,Ncol] =3    ; Don[Grp4,Ncol] =4 ; head(Don,3)
# 3 Tableau de contingence----
M = 0                                                                                               
for(i in 1:Ncol){ M[i]=max(Don[,i])-min(Don[,i])+1 }  
Som_mi =sum(M)
TDC =matrix(0,nrow=Nlig,ncol=Som_mi) ;  Index =0            
for(j in 1:Ncol){
  for(i in 1:Nlig){TDC[i,Index+as.integer(Don[i,j])]=1}
  Index = Index+M[j]}
#  4 Tableau de Burt----
Burt = t(TDC) %*% TDC     # tableau Burt = TDC’TDC
#  5 AFC sur le TDC
Res_ACM1 = CA(TDC)   
Res_ACM1$eig ; sum(Res_ACM1$eig)
