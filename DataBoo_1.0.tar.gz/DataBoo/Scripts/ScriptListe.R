## Création de la liste----
MaListe = list(
  CalculHypotenuse=function(x,y){z=(x^2+y^2)^0.5;z},
  Couleur = c("rouge", "vert" , "vert", "bleu"),
  Lambda = diag(1 :5)
) ; MaListe

## Sélection d’éléments de la liste----
MaListe$couleur
MaListe[1]
MaListe[[1]]   
MaListe[[1]](4,5)       # Calcul de l’hypothénuse
MaListe[[3]][3,]         # 3ème ligne de la la matrice
